﻿namespace Hospital_System.DAL.Models.Enums
{

    public enum PaymentStatus
    {
        PENDING = 0,
        PAID = 1
    }
}
