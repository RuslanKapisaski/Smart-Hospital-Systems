﻿
namespace Hospital_System.DAL.Models.Enums
{
    public enum AppointmentStatus
    {
        EXPRECTED = 0,
        DONE = 1
    }
}
