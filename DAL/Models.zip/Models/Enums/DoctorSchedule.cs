﻿
namespace Hospital_System.DAL.Models.Enums
{
   
        public enum DoctorSchedule
        {
            Morning,
            Afternoon,
            Night,
            OnCall,
            Off
        }

    
}
