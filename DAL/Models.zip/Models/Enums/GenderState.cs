﻿

namespace Hospital_System.DAL.Models.Enums
{
    public enum GenderState
    {
        M,
        F
    }
}
