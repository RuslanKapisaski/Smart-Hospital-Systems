﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_System.DAL.Models.DTOs
{
    class AppointmentDTO
    {
        public int appointmentID { get; set; }
        public DateTime apointmentDate { get; set; }
    }
}
