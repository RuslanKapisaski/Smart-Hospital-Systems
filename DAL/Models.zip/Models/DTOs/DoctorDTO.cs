﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hospital_System.DAL.Models.DTOs
{
    class DoctorDTO
    {
        public string fullName { get; set; }
        public string specialization { get; set; }
    }
}
